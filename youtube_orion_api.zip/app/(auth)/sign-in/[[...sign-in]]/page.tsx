import { SignIn } from "@clerk/nextjs";
import * as React from "react"

export default function Page() {
  return <SignIn />;
}
